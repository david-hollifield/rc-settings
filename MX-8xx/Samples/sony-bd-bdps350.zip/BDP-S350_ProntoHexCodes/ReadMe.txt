
Clean codes created with MakeHex (http://john.fine.home.comcast.net/ir/makehex.zip)

To create these codes I learnt all the codes from the remote supplied with the player
to identify the protocol, frequency, device number and function number. Then using this
info I created the clean codes.

I have created codes for 0 to 127. I haven't tried any of the codes not listed in
BDP-S350.htm included in this archive, but feel free to try at your own risk to see if
they do anything (good or bad).

The only commands I've listed (created) which are additional to those found on the
original remote are discrete on and discrete off.

Two CCF's are enclosed (created with Hex2CCF), one containing all codes and another
containing just those listed in BDP-S350.htm. Just hide my panels and alias to the
buttons from your own.

I haven't included for any of the "TV" related commands on the remote for obvious
reasons.

Hope you find this useful... Rob :)


